﻿using System;
using System.Collections.Generic;
using System.Text;


using Tailorit.Avaliacao.Domain.Contract.IUser;
using Tailorit.Avaliacao.Domain.Entities;
using Tailorit.Avalicao.Application.IApplication;

namespace Tailorit.Avalicao.Application.RepositoryApplication
{
    public class RepositoryApplication : IApplicationUser
    {
        private readonly ICotnractUser _repositoryUser;
        public RepositoryApplication(ICotnractUser repositoryUser)
        {
            _repositoryUser = repositoryUser;
        }

        public void AddUser(User EntityUser)
        {
            _repositoryUser.AddUser(EntityUser);
        }

        public List<Genre> GenreList()
        {
            return _repositoryUser.GenreList();
        }

        public User GetByUserId(int Id)
        {
            return _repositoryUser.GetByUserId(Id);
        }

        public List<User> List()
        {
            return _repositoryUser.List();
        }

        public void UpdateUser(User EntityUser)
        {
            _repositoryUser.UpdateUser(EntityUser);
        }
    }

}
