﻿using System;
using System.Collections.Generic;
using System.Text;
using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avalicao.Application.IApplication
{
   public interface IApplicationUser 
    {
         void AddUser(User EntityUser);
        void UpdateUser(User EntityUser);
        List<User> List();
        User GetByUserId(int Id);
        List<Genre> GenreList();
    }
}  
