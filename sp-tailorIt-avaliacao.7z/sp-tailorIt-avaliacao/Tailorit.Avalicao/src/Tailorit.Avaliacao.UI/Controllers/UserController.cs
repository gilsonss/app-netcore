﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tailorit.Avaliacao.Domain.Entities;
using Tailorit.Avalicao.Application.IApplication;
using Tailorit.Avalicao.Application.RepositoryApplication;

namespace Tailorit.Avaliacao.UI.Controllers
{
    public class UserController : Controller
    {
        private readonly IApplicationUser _applicationUser;

        public UserController(IApplicationUser applicationUser)

        {
            _applicationUser = applicationUser;
        }

        [HttpGet]
        public IActionResult Index()
        {
                      return View(_applicationUser.List());
        }

        public IActionResult Cadastrar()
        {
            ViewBag.ListaSexo = _applicationUser.GenreList();
            return View(new User());
        }

        [HttpPost]
        public IActionResult Cadastrar(User user, string status)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ListaSexo = _applicationUser.GenreList();
                return View(nameof(Cadastrar));
            }
            user.Active = true;
            _applicationUser.AddUser(user);

            ViewBag.ShowAlert = "<script>alert('Successfully Edited');  window.location.href = '/KnownIssues';</script>";

            return RedirectToAction(nameof(Index));

        }

        [HttpPost]
        public  IActionResult InativarUsuario(int userId)
        {
            if (userId != 0)
            {
                var usr = _applicationUser.GetByUserId(userId);
                usr.Active = false;
                _applicationUser.UpdateUser(usr);
                return RedirectToAction(nameof(Index));
            }            

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult AtivarUsuario(int userId)
        {
            if (userId != 0)
            {
                var usr = _applicationUser.GetByUserId(userId);
                usr.Active = true;
                _applicationUser.UpdateUser(usr);
                return RedirectToAction(nameof(Index));
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
