﻿using FluentValidation;

using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avaliacao.UI.Validation
{
    public class ValidationToUser : AbstractValidator<User>
    {
        public ValidationToUser()
        {
            RuleFor(x => x.Name).NotEmpty()
                .WithMessage("Campo Nome Obrigatório");

            RuleFor(n => n.Name).NotEmpty()
              .Custom((x, context) => {
                     if (!(string.IsNullOrEmpty(x)) && x.Length < 3)
                      context.AddFailure("O Nome deve ter no mínimo de 3 caracteres");
              });

            RuleFor(n => n.BirthDate).NotEmpty()
        .Custom((x, context) => {
            if (x.Year < 1900)
                context.AddFailure("Data Inválida");
        });


            RuleFor(x => x.BirthDate).NotEmpty()
               .WithMessage("Campo Data Nascimento Obrigatório");

           
            RuleFor(x=> x.GenreId).NotEmpty()
             .When(x => x.GenreId == 0).WithMessage("Campo Sexo Obrigatório");
        }
    }
}
