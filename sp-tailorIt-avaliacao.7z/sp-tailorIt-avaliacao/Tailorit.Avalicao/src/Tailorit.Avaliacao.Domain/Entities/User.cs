﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tailorit.Avaliacao.Domain.Entities
{
    [Table("User")]
    public class User
    {
        public int UserId { get; set; }

        [Display(Name = "Nome")]
        public string Name { get; set; }


        [Display(Name ="Data de Nascimento")]        
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date, ErrorMessage = "Uma data válida deve ser informada!")]
        public DateTime BirthDate { get; set; }

        [Display(Name = "E-Mail")]
        public string Email { get; set; }


        [Display(Name = "Senha")]
        public string Password { get; set; }


        public bool Active { get; set; }

        public int GenreId { get; set; }

    }
}
