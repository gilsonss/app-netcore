﻿using System.Collections.Generic;

using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avaliacao.Domain.Contract.IBaseUser
{
    public interface ICotnractBase <U , S> 
                                where U :class
                                where S : class
    {
        void AddUser(U EntityUser);
        void UpdateUser( U EntityUser);
        User GetByUserId(int Id);
        List<U> List();
        List<S> GenreList();
       

    }
}
