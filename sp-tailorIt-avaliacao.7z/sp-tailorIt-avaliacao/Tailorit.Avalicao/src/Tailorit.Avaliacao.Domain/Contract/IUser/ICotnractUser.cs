﻿using System;
using System.Collections.Generic;
using System.Text;

using Tailorit.Avaliacao.Domain.Contract.IBaseUser;
using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avaliacao.Domain.Contract.IUser
{
   public interface ICotnractUser : ICotnractBase<User,Genre>
    {
    }
}
