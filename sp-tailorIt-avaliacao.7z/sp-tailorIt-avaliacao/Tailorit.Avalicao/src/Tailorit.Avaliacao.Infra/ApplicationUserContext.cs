﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avaliacao.Infra
{
    public class ApplicationUserContext : DbContext

    {
        public ApplicationUserContext() : base()
        {

        }

        public ApplicationUserContext(DbContextOptions<ApplicationUserContext> options) : base(options)
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Genre> Genres { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<User>().HasKey(usr => usr.UserId);

            modelBuilder.Entity<Genre>().HasKey(gr => gr.GenreId);

            modelBuilder.Entity<User>()
            .Property(f => f.BirthDate)
            .HasColumnType("datetime");

        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=dbAvalicaoRemoto;Integrated Security=True",
                b => b.MigrationsAssembly("Tailorit.Avaliacao.UI"));
        }

    }

}
