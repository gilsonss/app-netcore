﻿using Tailorit.Avaliacao.Domain.Entities;
using Tailorit.Avaliacao.Domain.Contract.IUser;

namespace Tailorit.Avaliacao.Infra.Generic.Repository
{
    public class RepositoryUser : RepositoryBase<User,Genre>, ICotnractUser
    {
    }
}
