﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Tailorit.Avaliacao.Domain.Contract.IBaseUser;
using Tailorit.Avaliacao.Domain.Entities;

namespace Tailorit.Avaliacao.Infra.Generic.Repository
{
    public class RepositoryBase<U, S> : ICotnractBase<U , S> 
                                     where U:class
                                     where S:class
    {
        private readonly ApplicationUserContext _userContext;
  
        public RepositoryBase( )
        {
            _userContext = new ApplicationUserContext();
        }

        public void AddUser(U EntityUser)
        {
            _userContext.Set<U>().Add(EntityUser);
            _userContext.SaveChanges();
        }

           public List<S> GenreList()
        {
            return _userContext.Set<S>().ToList();
        }

        public User GetByUserId(int Id)
        {
            var usr = _userContext.Users.Find(Id);
            return usr;
        }

        public List<U> List()
        {
           return _userContext.Set<U>().ToList();
        }

        public void UpdateUser(U EntityUser)
        {
            _userContext.Update(EntityUser);
            _userContext.SaveChanges();
        }
    }
}
