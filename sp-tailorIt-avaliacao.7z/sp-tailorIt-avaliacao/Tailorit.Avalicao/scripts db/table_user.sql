
/*
    1� ) CRIAR BANCO DE DADOS  NOME >>> dbAvalicaoRemoto >> 
	      + Microsoft Sql Server Management Studio > Database >
		   clique bot�o direito > New Database > Name Database >> dbAvalicaoRemoto, OK;
*/

USE [dbAvalicaoRemoto]
GO

CREATE TABLE Genre(
   [GenreId] [int] IDENTITY(1,1) PRIMARY KEY,
   [Description] [VARCHAR](15) NOT NULL
);


CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL, /*Codigo*/
	[Name] VARCHAR(200) NOT NULL,      /*Nome*/
	[BirthDate] [DATETIME] NOT NULL,     /*Data de Nascimento*/
	[Email] [VARCHAR](100)NOT NULL,      /*E-mail*/
	[Password] [VARCHAR](100)  NULL,   /*Senha*/
	[Active] BIT DEFAULT '1' NOT NULL,     /*Ativo*/
	[GenreId] [int] NOT NULl,
	PRIMARY KEY (UserId),
    FOREIGN KEY (GenreId) REFERENCES Genre(GenreId)
);
  

INSERT INTO [dbo].[Genre] ([Description]) VALUES ('Masculino');

INSERT INTO [dbo].[Genre] ([Description]) VALUES ('Feminino');

